#!/bin/sh

rm -rf GCMC_input
rm -rf *.cif *.mol *.xyz *.vol *.sa *.res *.dat
